#!/bin/bash

# 定义输入和输出文件夹
input_dir="/mnt/d/SRA数据库相关/SRA-RAW_data/5_hisat2_sam_results"
output_dir="/mnt/d/SRA数据库相关/SRA-RAW_data/6_sorted_bam"

# 确保输出目录存在
mkdir -p "$output_dir"

# 检查输入目录
if [ ! -d "$input_dir" ]; then
    echo "错误: 输入目录不存在: $input_dir"
    exit 1
fi

echo "开始处理SAM文件..."
echo "输入目录: $input_dir"
echo "输出目录: $output_dir"

# 使用for循环处理每个SAM文件
for sam_file in "$input_dir"/*.sam; do
    if [ -f "$sam_file" ]; then
        base_name=$(basename "$sam_file" .sam)
        echo "正在处理: $base_name"
        
        # SAM转BAM + 排序 + 索引
        samtools view -b -@ 3 "$sam_file" | \
        samtools sort -@ 3 -o "$output_dir/$base_name.sorted.bam" && \
        samtools index "$output_dir/$base_name.sorted.bam"
        
        if [ $? -eq 0 ]; then
            echo "完成: $base_name"
        else
            echo "错误: 处理 $base_name 时出现问题"
        fi
    fi
done

echo "所有SAM文件处理完成!"
echo "排序后的BAM文件保存在: $output_dir"
'

