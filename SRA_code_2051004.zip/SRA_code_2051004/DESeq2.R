# 加载必要的包
if (!require(DESeq2)) {
  BiocManager::install("DESeq2")
  library(DESeq2)
}

if (!require(dplyr)) {
  install.packages("dplyr")
  library(dplyr)
}

if (!require(ggplot2)) {
  install.packages("ggplot2")
  library(ggplot2)
}
# 数据预处理
cat("=== 数据预处理 ===\n")
head(expr)
expr2<-expr
library(dplyr)
library(tibble)
expr_final <- expr2 %>%
  rownames_to_column("gene") %>%
  mutate(gene = gsub("mir", "miR", gene)) %>%
  group_by(gene) %>%
  slice_max(row_mean, n = 1, with_ties = FALSE) %>%
  ungroup() %>%
  # 再次确保没有重复的gene
  distinct(gene, .keep_all = TRUE) %>%
  column_to_rownames("gene") %>%
  select(-row_mean)
expr<-expr_final
# 确保expr是数值矩阵
expr_matrix <- as.matrix(expr)
cat("表达矩阵维度:", dim(expr_matrix), "\n")

# 检查分组信息
cat("分组信息:\n")
print(table(group$group))

# 准备样本信息
sample_info <- data.frame(
  row.names = group$RUN,
  condition = factor(group$group),
  sample = group$Ssample
)

# 确保样本顺序一致
common_samples <- intersect(colnames(expr_matrix), rownames(sample_info))
expr_filtered <- expr_matrix[, common_samples]
sample_info_filtered <- sample_info[common_samples, ]

cat("共同样本数量:", length(common_samples), "\n")

# 创建DESeq2数据集
cat("=== 创建DESeq2数据集 ===\n")
dds <- DESeqDataSetFromMatrix(
  countData = round(expr_filtered),  # DESeq2需要整数计数
  colData = sample_info_filtered,
  design = ~ condition
)

cat("原始基因数量:", nrow(dds), "\n")

# 过滤低表达基因
cat("=== 过滤低表达基因 ===\n")
keep <- rowSums(counts(dds) >= 10) >= 3  # 至少在3个样本中counts>=10
dds <- dds[keep, ]
cat("过滤后基因数量:", nrow(dds), "\n")

# 差异表达分析
cat("=== 进行差异表达分析 ===\n")
dds <- DESeq(dds)

# 获取结果
cat("=== 获取差异表达结果 ===\n")
res <- results(dds, contrast = c("condition", "Plaque", "Marginal"))
res <- res[order(res$padj), ]  # 按调整p值排序

# 添加基因名称
res_df <- as.data.frame(res)
res_df$miRNA <- rownames(res_df)

# 筛选显著差异表达的miRNA
significant_genes <- res_df %>%
  filter(padj < 0.05 & abs(log2FoldChange) > 1)  # FDR < 0.05, |log2FC| > 1

cat("显著差异表达miRNA数量:", nrow(significant_genes), "\n")
cat("上调miRNA数量:", sum(significant_genes$log2FoldChange > 0), "\n")
cat("下调miRNA数量:", sum(significant_genes$log2FoldChange < 0), "\n")

# 保存结果
write.csv(res_df, "miRNA_DEG_results_all.csv", row.names = FALSE)
write.csv(significant_genes, "miRNA_DEG_significant.csv", row.names = FALSE)

# 可视化
cat("=== 生成可视化图形 ===\n")

#可视化
# 1. MA图
pdf("MA_plot.pdf", width = 12, height = 9)
plotMA(res, main = "MA Plot - Plaque vs Marginal")
dev.off()
cat("已生成: MA_plot.pdf\n")

# 2. 火山图
volcano_data <- res_df %>%
  mutate(significant = padj < 0.05 & abs(log2FoldChange) > 1)

pdf("volcano_plot.pdf", width = 16, height = 12)
ggplot(volcano_data, aes(x = log2FoldChange, y = -log10(pvalue))) +
  geom_point(aes(color = significant), alpha = 0.6, size = 2) +  
  scale_color_manual(values = c("grey", "red")) +
  theme_minimal(base_size = 20) +  # 增加基础字体大小
  labs(title = "Volcano Plot - Plaque vs Marginal",
       x = "log2 Fold Change", y = "-log10 p-value") +
  geom_hline(yintercept = -log10(0.05), linetype = "dashed", linewidth = 1) +  
  geom_vline(xintercept = c(-1, 1), linetype = "dashed", linewidth = 1) +  
  theme(
    plot.title = element_text(size = 22, face = "bold"),  # 标题字体更大
    axis.title = element_text(size = 20),  # 坐标轴标题
    axis.text = element_text(size = 20),   # 坐标轴刻度文字
    legend.text = element_text(size = 18), # 图例文字
    legend.title = element_text(size = 18) # 图例标题
  )
dev.off()

# 3. 热图（前30个显著差异miRNA）
if (nrow(significant_genes) > 0) {
  top_genes <- head(significant_genes$miRNA, 30)
  expr_top <- expr_filtered[top_genes, ]
  
  # 标准化表达量
  expr_top_norm <- t(scale(t(expr_top)))
  
  pdf("heatmap_top_DEGs.pdf", width = 10, height = 8)
  pheatmap::pheatmap(expr_top_norm,
                     main = "Top 30 Differentially Expressed miRNAs",
                     annotation_col = sample_info_filtered["condition"],
                     show_rownames = TRUE,
                     fontsize_row = 8)
  dev.off()
  cat("已生成: heatmap_top_DEGs.pdf\n")
} else {
  cat("没有显著差异基因，跳过热图生成\n")
}

# 结果总结
cat("\n=== 差异表达分析完成 ===\n")
cat("总基因数:", nrow(res_df), "\n")
cat("显著差异基因数 (FDR < 0.05 & |log2FC| > 1):", nrow(significant_genes), "\n")
cat("最小调整p值:", min(res_df$padj, na.rm = TRUE), "\n")
cat("最大|log2FoldChange|:", max(abs(res_df$log2FoldChange), na.rm = TRUE), "\n")

# 显示最显著的miRNA
cat("\n前10个最显著的差异表达miRNA:\n")
print(head(res_df, 10)[, c("miRNA", "log2FoldChange", "pvalue", "padj")])
save.image(file = "D:/SRA数据库相关/SRA-RAW_data/7_count/SRP515368.RData")





