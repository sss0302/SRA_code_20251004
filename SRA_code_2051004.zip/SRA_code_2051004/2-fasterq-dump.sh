#!/bin/bash

# 设置工具路径（Windows格式）
export TOOL_PATH="D:/sratoolkit.3.2.1-win64/bin/fasterq-dump.exe"

# 设置输出目录（Windows格式）
OUTPUT_DIR="D:/SRA数据库相关/SRA-RAW_data/2_Fastq"

# 设置输入目录（Windows格式）
INPUT_DIR="D:/SRA数据库相关/SRA-RAW_data/1_SRA"

# 检查工具路径是否存在
if [ ! -f "$TOOL_PATH" ]; then
    echo "错误：指定的工具路径 $TOOL_PATH 不存在！"
    echo "请确认sratoolkit已正确安装"
    exit 1
fi

# 检查输出目录是否存在，不存在则创建
if [ ! -d "$OUTPUT_DIR" ]; then
    mkdir -p "$OUTPUT_DIR"
    echo "创建输出目录：$OUTPUT_DIR"
fi

# 检查输入目录是否存在
if [ ! -d "$INPUT_DIR" ]; then
    echo "错误：输入目录 $INPUT_DIR 不存在！"
    exit 1
fi

# 查找并处理 .sra 文件
echo "开始处理 SRA 文件..."
count=0
success_count=0

# 切换到输入目录
cd "$INPUT_DIR"

# 处理所有 .sra 文件
for sra_file in *.sra; do
    if [ -f "$sra_file" ]; then
        filename=$(basename "$sra_file")
        accession="${filename%.*}"
        
        echo "正在处理: $filename ($((count+1))/$(( $(ls *.sra | wc -l) )))"
        
        # 直接在当前目录运行 fasterq-dump
        if "$TOOL_PATH" "$filename" -O "$OUTPUT_DIR" -e 12 --split-files; then
            echo "成功处理: $filename"
            ((success_count++))
        else
            echo "处理失败: $filename"
        fi
        
        ((count++))
        echo "进度: 已尝试处理 $count 个文件，成功 $success_count 个"
        echo "----------------------------------------"
    fi
done

# 完成提示
echo "文件处理完成！共尝试处理 $count 个文件，成功 $success_count 个。"
echo "输出路径：$OUTPUT_DIR"