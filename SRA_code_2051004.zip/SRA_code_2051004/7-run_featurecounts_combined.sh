#!/bin/bash

# 定义输入目录和输出目录
input_dir="/mnt/d/SRA数据库相关/SRA-RAW_data/6_sorted_bam"
output_dir="/mnt/d/SRA数据库相关/SRA-RAW_data/7_featurecounts_mirna"
gtf_file="/mnt/d/SRA数据库相关/SRA-RAW_data/脚本文件/7_featurecounts/Homo_sapiens.GRCh38.115.chr.gtf"

# 如果输出文件夹不存在，则创建它
mkdir -p "$output_dir"

# 检查工具和文件
if ! command -v featureCounts &> /dev/null; then
    echo "错误: featureCounts 未安装。请运行: sudo apt install subread"
    exit 1
fi

if [ ! -d "$input_dir" ]; then
    echo "错误: 输入目录不存在: $input_dir"
    exit 1
fi

if [ ! -f "$gtf_file" ]; then
    echo "错误: GTF文件不存在: $gtf_file"
    exit 1
fi

echo "开始miRNA基因表达定量分析..."
echo "输入目录: $input_dir"
echo "输出目录: $output_dir"
echo "GTF文件: $gtf_file"

# 进入包含BAM文件的目录
cd "$input_dir" || exit

# 检查是否有BAM文件
if [ $(ls *.sorted.bam 2>/dev/null | wc -l) -eq 0 ]; then
    echo "错误: 在 $input_dir 中未找到BAM文件"
    exit 1
fi

# 创建BAM文件列表
bam_list="$output_dir/bam_files.txt"
ls *.sorted.bam > "$bam_list"

echo "找到 $(wc -l < "$bam_list") 个BAM文件"

# 使用基本的featureCounts参数
echo "运行featureCounts..."
featureCounts -a "$gtf_file" -o "$output_dir/mirna_counts.txt" -T 8 -t "exon" -g "gene_id" -s 0 -M -O --minOverlap 1 -Q 10 -b "$bam_list"

if [ $? -eq 0 ]; then
    echo "featureCounts运行成功!"
    
    # 为每个BAM文件生成单独的计数文件
    echo "生成单独的计数文件..."
    for bam_file in *.sorted.bam; do
        base_name=$(basename "$bam_file" .sorted.bam)
        # 从主计数文件中提取该样本的列
        head -n 1 "$output_dir/mirna_counts.txt" | cut -f1,7- > "$output_dir/${base_name}_counts.txt"
        grep -v "^#" "$output_dir/mirna_counts.txt" | cut -f1,7- >> "$output_dir/${base_name}_counts.txt"
        
        echo "生成: ${base_name}_counts.txt"
    done
    
    echo "生成的计数文件:"
    ls -la "$output_dir"/*_counts.txt
    
    # 创建样本列表文件，供Windows R使用
    echo "创建样本列表..."
    ls *.sorted.bam | sed 's/.sorted.bam//' > "$output_dir/sample_list.txt"
    
else
    echo "featureCounts运行失败"
    exit 1
fi

echo "WSL miRNA定量分析完成!"
echo "结果保存在: $output_dir"