#!/bin/bash
# HISAT2比对脚本 - 仅输出SAM格式

reference_dir="/mnt/d/SRA数据库相关/SRA-RAW_data/4_reference_index"
input_dir="/mnt/d/SRA数据库相关/SRA-RAW_data/3_Fastq_clean"
output_dir="/mnt/d/SRA数据库相关/SRA-RAW_data/5_hisat2_sam_results"

mkdir -p "$output_dir"

echo "开始miRNA比对 (输出SAM格式)..."

# 计数器
count=0
total=$(ls "$input_dir"/*.clean.fastq | wc -l)

# 检查可用内存
available_mem=$(free -g | grep Mem | awk '{print $7}')
echo "系统可用内存: ${available_mem}GB"

for file in "$input_dir"/*.clean.fastq; do
    if [ -f "$file" ]; then
        count=$((count+1))
        sample=$(basename "$file" .clean.fastq)
        echo "[$count/$total] 处理: $sample"
        
        # 检查文件大小
        file_size=$(stat -c%s "$file")
        file_size_mb=$((file_size/1024/1024))
        echo "  输入文件大小: ${file_size_mb}MB"
        
        # 使用单线程确保稳定性
        threads=1
        
        echo "  运行HISAT2比对..."
        hisat2 -p $threads \
               --no-spliced-alignment \
               --no-softclip \
               --min-intronlen 20 \
               --max-intronlen 50000 \
               --no-mixed \
               --no-discordant \
               -x "$reference_dir/grch38/genome" \
               -U "$file" \
               -S "$output_dir/${sample}.sam" \
               2>"$output_dir/${sample}.log"
        
        if [ $? -eq 0 ]; then
            # 显示SAM文件大小
            sam_size=$(ls -lh "$output_dir/${sample}.sam" | awk '{print $5}')
            echo "  ✓ 完成: $sample.sam ($sam_size)"
            
            # 显示比对统计（从日志中提取）
            if grep -q "aligned exactly 1 time" "$output_dir/${sample}.log"; then
                aligned=$(grep "aligned exactly 1 time" "$output_dir/${sample}.log" | awk '{print $1}')
                total_reads=$(grep "reads; of these:" "$output_dir/${sample}.log" | awk '{print $1}')
                if [ ! -z "$aligned" ] && [ ! -z "$total_reads" ]; then
                    ratio=$((aligned*100/total_reads))
                    echo "  比对统计: $aligned/$total_reads ($ratio%)"
                fi
            fi
        else
            echo "  ✗ 失败: $sample"
            echo "  请查看日志: $output_dir/${sample}.log"
        fi
        
        echo "----------------------------------------"
        
        # 清理缓存
        sync
        echo 3 | sudo tee /proc/sys/vm/drop_caches > /dev/null 2>&1
    fi
done

echo "HISAT2比对阶段完成!"
echo "SAM文件保存在: $output_dir"
