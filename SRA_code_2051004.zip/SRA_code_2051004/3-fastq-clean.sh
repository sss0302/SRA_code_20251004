#!/bin/bash

# 定义输入和输出文件夹（注意：WSL中Windows路径的访问方式）
input_dir="/mnt/d/SRA数据库相关/SRA-RAW_data/2_Fastq"
output_dir="/mnt/d/SRA数据库相关/SRA-RAW_data/3_Fastq_clean"

# 如果输出文件夹不存在，则创建
mkdir -p "$output_dir"

# 创建日志文件
log_file="$output_dir/processing_log.txt"
echo "FASTQ质控处理开始于: $(date)" > "$log_file"

# 查找所有fastq文件并处理（单端测序）
find "$input_dir" -name "*.fastq" | while read file; do
    filename=$(basename "$file" .fastq)
    output_file="$output_dir/${filename}.clean.fastq"
    
    echo "处理单端测序文件: $filename" | tee -a "$log_file"
    echo "输入文件: $file" >> "$log_file"
    echo "输出文件: $output_file" >> "$log_file"
    
    # 运行fastp质控
    fastp -i "$file" -o "$output_file" -w 2 -h "$output_dir/${filename}_report.html" -j "$output_dir/${filename}_report.json"
    
    # 检查命令是否成功执行
    if [ $? -eq 0 ]; then
        echo "成功处理: $filename" | tee -a "$log_file"
    else
        echo "处理失败: $filename" | tee -a "$log_file"
    fi
    echo "----------------------------------------" >> "$log_file"
done

echo "所有单端FASTQ文件处理完成，输出保存在 $output_dir" | tee -a "$log_file"