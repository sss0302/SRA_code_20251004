#!/bin/bash

# 设置 prefetch 工具路径
export PATH="/d/sratoolkit.3.2.1-win64/bin:$PATH"

# 设置输出目录
OUTPUT_DIR="/d/SRA数据库相关/SRA-RAW_data/1_SRA"

# 创建输出目录
mkdir -p "$OUTPUT_DIR"

# 设置网络优化参数
export VDB_TIMEOUT=60
export VDB_RETRIES=5

# 检查 SRA 列表文件是否存在
SRA_LIST="sra_list.txt"
if [ ! -f "$SRA_LIST" ]; then
    echo "错误：SRA 列表文件 $SRA_LIST 不存在！"
    exit 1
fi

echo "开始下载SRA运行文件（优化网络设置）..."
echo "输出目录: $OUTPUT_DIR"
echo "超时设置: 60秒，重试次数: 5次"

counter=0
total=$(wc -l < "$SRA_LIST")
success_count=0
fail_count=0
failed_list=()

while IFS= read -r sra_id; do
    if [ -n "$sra_id" ]; then
        counter=$((counter + 1))
        sra_id=$(echo "$sra_id" | tr -d '\r\n' | xargs)
        
        echo "--- [$counter/$total] 下载: $sra_id ---"
        
        # 使用优化的prefetch参数
        prefetch -O "$OUTPUT_DIR" --max-size 100G --progress --verbose "$sra_id"
        
        if [ $? -eq 0 ]; then
            echo "✓ 成功下载: $sra_id"
            success_count=$((success_count + 1))
        else
            echo "✗ 下载失败: $sra_id"
            fail_count=$((fail_count + 1))
            failed_list+=("$sra_id")
            
            # 等待一下再继续
            sleep 5
        fi
        echo ""
    fi
done < "$SRA_LIST"

echo "=== 下载总结 ==="
echo "成功: $success_count"
echo "失败: $fail_count"
echo "输出目录: $OUTPUT_DIR"

if [ $fail_count -gt 0 ]; then
    echo "失败的SRR编号:"
    printf '%s\n' "${failed_list[@]}"
    
    # 保存失败列表
    printf '%s\n' "${failed_list[@]}" > "failed_downloads.txt"
    echo "失败列表已保存到: failed_downloads.txt"
fi