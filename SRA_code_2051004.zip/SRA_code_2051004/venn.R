setwd("D:/颈动脉内皮外囊泡")
library(openxlsx)
library(readr)
PE <- read.xlsx("D:/颈动脉内皮外囊泡/PCSK9&exsome.xlsx")
miRTarBase_MTI <- read_csv("D:/颈动脉内皮外囊泡/miRTarBase_MTI.csv")
miRNA_DEG_significant<-read_csv("D:/颈动脉内皮外囊泡/miRNA_DEG_significant - 副本.csv")

# 加载必要的包
library(dplyr)

# 1. 删除重复值，保留唯一值
PE <- PE %>%
  distinct(`PCSK9_related_miRNAs`, .keep_all = TRUE)

# 2. 删除所有"hsa-"，保留"miR"及其以后的部分
head(miRNA_DEG_significant,n=2)
EV <- miRNA_DEG_significant %>%
  select(miRNA)
EV <- EV %>%
  mutate(`miRNA` = gsub("hsa-", "", `miRNA`))

head(PE,n=2)
head(EV,n=2)

#venn
library(VennDiagram)
PCSK9_miRNAs <- PE$PCSK9_related_miRNAs
EV_miRNAs <- EV$miRNA
PCSK9_count <- length(PCSK9_miRNAs)
EV_count <- length(EV_miRNAs)
intersection_count <- length(intersect(PCSK9_miRNAs, EV_miRNAs))
# 创建韦恩图
venn.plot <- draw.pairwise.venn(
  area1 = PCSK9_count,
  area2 = EV_count,
  cross.area = intersection_count,
  category = c("PCSK9-miRNA", "EV-miRNA"),
  fill = c("lightblue", "lightpink"),
  alpha = 0.7,
  lty = "blank",
  cex = 2,                    # 数字大小
  cat.cex = 1.2,              # 缩小类别标签文字
  cat.pos = c(0, 0),          # 类别标签位置（0=正上方）
  cat.dist = 0.03,            # 类别标签与圆圈的距离
  cat.just = list(c(0.5, 0.5), c(0.5, 0.5)), # 居中标签
  scaled = FALSE,              # 禁用自动缩放，使圆圈大小更均匀
  main = "The intersection of PCSK9-miRNA and EV-miRNA",
  main.cex = 1.5,
  main.pos = c(0.5, 0.1)     # 标题位置（x=0.5居中，y=0.05底部）
)

# 显示韦恩图
grid.draw(venn.plot)

# 保存为PDF
pdf("Venn_diagram.pdf", width = 8, height = 8)
grid.draw(venn.plot)
dev.off()

# 提取交集miRNA
intersection_miRNAs <- intersect(PCSK9_miRNAs, EV_miRNAs)

# 创建新的数据框
PCSK9_EV_miRNA <- data.frame(miRNA = intersection_miRNAs)

head(PCSK9_EV_miRNA,N=1)
head(miRTarBase_MTI)
PCSK9_EV_miRNA_with_prefix <- PCSK9_EV_miRNA %>%
  mutate(miRNA = paste0("hsa-", miRNA))

matched_data <- miRTarBase_MTI %>%
  filter(miRNA %in% PCSK9_EV_miRNA_with_prefix$miRNA)

cat("匹配到的行数:", nrow(matched_data), "\n")
head(matched_data)

# 如果需要查看匹配到的miRNA列表
matched_miRNAs <- unique(matched_data$miRNA)
cat("匹配到的miRNA数量:", length(matched_miRNAs), "\n")

#富集分析
# 加载包
library(clusterProfiler)
library(org.Hs.eg.db)
library(enrichplot)
library(ggplot2)
library(dplyr)
#library(BiocManager)
#options(repos = c(CRAN = "https://mirrors.tuna.tsinghua.edu.cn/CRAN/"))
#BiocManager::install(c("clusterProfiler", "DOSE", "enrichplot"), force = TRUE)

# 提取Target Gene的Entrez ID
target_genes <- matched_data$`Target Gene (Entrez ID)`
target_genes <- unique(na.omit(target_genes))  # 去除NA和重复值
cat("用于富集分析的基因数量:", length(target_genes), "\n")
# KEGG通路富集分析
kegg_enrich <- enrichKEGG(
  gene = target_genes,
  organism = "hsa",  # 人类
  pvalueCutoff = 0.05,
  qvalueCutoff = 0.2,
  keyType = "kegg"
)

# GO富集分析（包括BP、CC、MF）
go_enrich <- enrichGO(
  gene = target_genes,
  OrgDb = org.Hs.eg.db,
  keyType = "ENTREZID",
  ont = "ALL",  # 包括BP、CC、MF
  pvalueCutoff = 0.05,
  qvalueCutoff = 0.2,
  readable = TRUE  # 将基因ID转换为基因名
)

# KEGG气泡图
if (nrow(kegg_enrich) > 0) {
  kegg_dotplot <- dotplot(kegg_enrich, showCategory=15) + 
    ggtitle("KEGG Pathway Enrichment Analysis") +
    theme(plot.title = element_text(hjust = 0.5, size=14, face="bold"))
  print(kegg_dotplot)
  
  # 保存KEGG图
  ggsave("KEGG_enrichment_dotplot.pdf", plot=kegg_dotplot, width=10, height=8)
} else {
  cat("没有显著富集的KEGG通路\n")
}

# GO富集结果分面显示
if (nrow(go_enrich) > 0) {
  # 获取GO富集结果数据框
  go_data <- as.data.frame(go_enrich)
  
  # 计算每个类别中描述的最大字符数，用于动态调整图形高度
  max_chars_bp <- if("BP" %in% go_data$ONTOLOGY) {
    max(nchar(as.character(go_data$Description[go_data$ONTOLOGY == "BP"])))
  } else 0
  
  max_chars_mf <- if("MF" %in% go_data$ONTOLOGY) {
    max(nchar(as.character(go_data$Description[go_data$ONTOLOGY == "MF"])))
  } else 0
  
  max_chars_cc <- if("CC" %in% go_data$ONTOLOGY) {
    max(nchar(as.character(go_data$Description[go_data$ONTOLOGY == "CC"])))
  } else 0
  
  # 根据最大字符数动态计算图形高度
  base_height <- 10
  extra_height_per_char <- 0.15  # 增加每个字符对应的高度系数
  dynamic_height <- base_height + (max(max_chars_bp, max_chars_mf, max_chars_cc) * extra_height_per_char)
  
  
  # GO富集结果分面显示 - 简化版本
  if (nrow(go_enrich) > 0) {
    # GO气泡图（按ontology分面）- 减小宽度，增加高度
    go_dotplot <- dotplot(go_enrich, split="ONTOLOGY", showCategory=10) + 
      facet_grid(ONTOLOGY~., scale="free") +
      ggtitle("GO Enrichment Analysis") +
      theme(
        plot.title = element_text(hjust = 0.5, size=14, face="bold"),
        axis.text.y = element_text(size = 9),  # 减小文本大小
        plot.margin = margin(1, 1, 1, 1.5, "cm")  # 增加左侧边距
      )
    
    print(go_dotplot)
    
    # 保存GO图 - 减小宽度，增加高度
    ggsave("GO_enrichment_dotplot.pdf", plot=go_dotplot, width=10, height=14)
    
    # 分别绘制BP、CC、MF
    ontologies <- c("BP", "CC", "MF")
    for (ont in ontologies) {
      ont_enrich <- enrichGO(
        gene = target_genes,
        OrgDb = org.Hs.eg.db,
        keyType = "ENTREZID",
        ont = ont,
        pvalueCutoff = 0.05,
        qvalueCutoff = 0.2,
        readable = TRUE
      )
      
      if (nrow(ont_enrich) > 0) {
        ont_plot <- dotplot(ont_enrich, showCategory=15) + 
          ggtitle(paste("GO", 
                        switch(ont, 
                               "BP" = "Biological Process",
                               "CC" = "Cellular Component", 
                               "MF" = "Molecular Function"))) +
          theme(
            plot.title = element_text(hjust = 0.5, size=14, face="bold"),
            axis.text.y = element_text(size = 9),
            plot.margin = margin(1, 1, 1, 1.5, "cm")
          )
        print(ont_plot)
        ggsave(paste0("GO_", ont, "_dotplot.pdf"), plot=ont_plot, width=9, height=12)
      }
    }
    
  } else {
    cat("没有显著富集的GO term\n")
  }

# 保存结果到文件
if (nrow(kegg_enrich) > 0) {
  kegg_results <- as.data.frame(kegg_enrich)
  write.csv(kegg_results, "KEGG_enrichment_results.csv", row.names=FALSE)
  cat("KEGG富集分析结果已保存到 KEGG_enrichment_results.csv\n")
}

if (nrow(go_enrich) > 0) {
  go_results <- as.data.frame(go_enrich)
  write.csv(go_results, "GO_enrichment_results.csv", row.names=FALSE)
  cat("GO富集分析结果已保存到 GO_enrichment_results.csv\n")
}

write.csv(PE, "PE.csv", row.names=FALSE)
write.csv(matched_data, "matched_data.csv", row.names=FALSE)
write.csv(PCSK9_EV_miRNA, "PCSK9_EV_miRNA.csv", row.names=FALSE)















